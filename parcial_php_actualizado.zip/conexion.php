<?php
class Conexion {
    private $pdo;

    public function __construct() {
        try {
            $this->pdo = new PDO("mysql:host=127.0.0.1;dbname=parcialphp","root","");
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error: " . $e->getMessage());
        }
    }

    public function insertar($nombre, $apellido, $edad, $sexo, $pais, $nacionalidad, $temas, $observaciones, $fecha) {
        $sql = "INSERT INTO inscriptores(nombre, apellido, edad, sexo, pais, nacionalidad, temas, observaciones, fecha)
                VALUES (?,?,?,?,?,?,?,?,?)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$nombre, $apellido, $edad, $sexo, $pais, $nacionalidad, $temas, $observaciones, $fecha]);
    }

    public function obtenerInscriptores() {
        return $this->pdo->query("SELECT * FROM inscriptores ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>