CREATE DATABASE parcialphp;
USE parcialphp;

CREATE TABLE inscriptores (
id INT AUTO_INCREMENT PRIMARY KEY,
nombre VARCHAR(50),
apellido VARCHAR(50),
edad INT,
sexo VARCHAR(20),
pais VARCHAR(50),
nacionalidad VARCHAR(50),
temas TEXT,
observaciones TEXT,
fecha DATE
);