<?php
require_once "conexion.php";
$db = new Conexion();
$datos = $db->obtenerInscriptores();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Reporte</title>
<style>
table { width:100%; border-collapse:collapse; }
td, th { border:1px solid #000; padding:6px; }
th { background:#333; color:white; }
</style>
</head>
<body>

<h2>Reporte de Inscripciones</h2>

<table>
<tr>
<th>ID</th>
<th>Nombre</th>
<th>Apellido</th>
<th>Edad</th>
<th>Sexo</th>
<th>País</th>
<th>Nacionalidad</th>
<th>Temas</th>
<th>Observaciones</th>
<th>Fecha</th>
</tr>

<?php foreach($datos as $fila): ?>
<tr>
<td><?= $fila['id'] ?></td>
<td><?= $fila['nombre'] ?></td>
<td><?= $fila['apellido'] ?></td>
<td><?= $fila['edad'] ?></td>
<td><?= $fila['sexo'] ?></td>
<td><?= $fila['pais'] ?></td>
<td><?= $fila['nacionalidad'] ?></td>
<td><?= $fila['temas'] ?></td>
<td><?= $fila['observaciones'] ?></td>
<td><?= $fila['fecha'] ?></td>
</tr>
<?php endforeach; ?>

</table>

</body>
</html>