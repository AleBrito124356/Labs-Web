<?php
require_once "conexion.php";

$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nombre = ucfirst(strtolower(trim($_POST['nombre'])));
    $apellido = ucfirst(strtolower(trim($_POST['apellido'])));
    $edad = intval($_POST['edad']);
    $sexo = $_POST['sexo'];
    $pais = trim($_POST['pais']);
    $nacionalidad = trim($_POST['nacionalidad']);
    $temas = isset($_POST['tema']) ? implode(", ", $_POST['tema']) : "";
    $observaciones = trim($_POST['obs']);
    $fecha = $_POST['fecha']; // FECHA SELECCIONADA POR EL USUARIO

    if ($nombre == "" || $apellido == "" || $edad <= 0 || $sexo == "" || $pais == "" || $nacionalidad == "" || $fecha == "") {
        $mensaje = "Todos los campos son obligatorios.";
    } else {
        $db = new Conexion();
        if ($db->insertar($nombre, $apellido, $edad, $sexo, $pais, $nacionalidad, $temas, $observaciones, $fecha)) {
            $mensaje = "Datos guardados correctamente.";
        } else {
            $mensaje = "Error al guardar los datos.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Formulario PHP</title>
<style>
body {
    font-family: Arial;
    background: linear-gradient(to right, #7db9e8, #1e5799);
    padding: 20px;
    color:#fff;
}
form {
    background:#ffffff22;
    padding:20px;
    border-radius:10px;
    width:400px;
}
label { font-weight:bold; }
input, select, textarea {
    width: 100%;
    padding: 6px;
    border-radius: 5px;
    margin-bottom: 10px;
}
button {
    padding:10px 20px;
    background:#222;
    color:#fff;
    border:none;
    border-radius:6px;
}
footer {
    margin-top:20px;
    font-size:12px;
    text-align:center;
}
</style>
</head>

<body>

<h2>Formulario de Inscripción</h2>

<p><?= $mensaje ?></p>

<form method="POST">

<label>Nombre:</label>
<input type="text" name="nombre" required>

<label>Apellido:</label>
<input type="text" name="apellido" required>

<label>Edad:</label>
<input type="number" name="edad" required>

<label>Sexo:</label>
<select name="sexo" required>
<option>Masculino</option>
<option>Femenino</option>
</select>

<label>País de residencia:</label>
<input type="text" name="pais" required>

<label>Nacionalidad:</label>
<input type="text" name="nacionalidad" required>

<label>Tema tecnológico que te gustaría aprender:</label><br>
<input type="checkbox" name="tema[]" value="Correo"> Correo  
<input type="checkbox" name="tema[]" value="Celular"> Celular  
<input type="checkbox" name="tema[]" value="Internet"> Internet  
<br><br>

<label>Fecha del formulario:</label>
<input type="date" name="fecha" required>

<label>Observaciones:</label>
<textarea name="obs"></textarea>

<button type="submit">Guardar</button>

<br><br>
<a href="reporte.php" style="color:yellow;">Ver reporte</a>

</form>

<footer>
© 2025 iTECH. All rights reserved.
</footer>

</body>
</html>